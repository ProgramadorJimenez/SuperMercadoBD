const { sequelize } = require('../config/database');

const Proveedor = require('./proveedor')(sequelize);
const Producto = require('./producto')(sequelize);
const Usuario = require('./usuario')(sequelize);
const Venta = require('./venta')(sequelize);
const DetalleVenta = require('./detalleVenta')(sequelize);

// Proveedor 1 --- N Productos
Proveedor.hasMany(Producto, { foreignKey: 'providerId', as: 'productos', onDelete: 'RESTRICT', onUpdate: 'CASCADE' });
Producto.belongsTo(Proveedor, { foreignKey: 'providerId', as: 'proveedor' });

// Usuario 1 --- N Ventas
Usuario.hasMany(Venta, { foreignKey: 'userId', as: 'ventas', onDelete: 'RESTRICT', onUpdate: 'CASCADE' });
Venta.belongsTo(Usuario, { foreignKey: 'userId', as: 'usuario' });

// Venta 1 --- N DetalleVenta
Venta.hasMany(DetalleVenta, { foreignKey: 'saleId', as: 'detalles', onDelete: 'CASCADE', onUpdate: 'CASCADE' });
DetalleVenta.belongsTo(Venta, { foreignKey: 'saleId', as: 'venta' });

// Producto 1 --- N DetalleVenta
Producto.hasMany(DetalleVenta, { foreignKey: 'productId', as: 'detalles', onDelete: 'RESTRICT', onUpdate: 'CASCADE' });
DetalleVenta.belongsTo(Producto, { foreignKey: 'productId', as: 'producto' });

module.exports = {
  sequelize,
  Proveedor,
  Producto,
  Usuario,
  Venta,
  DetalleVenta
};
